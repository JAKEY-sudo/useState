import React from "react";
import Header from "./components/Header/Header";

function App() {
  return (
    <div className="App">
      <p>
        djkl;fghfgzsl;gklsdlkfnhlhn
      </p>
      <Header />

    </div>
  );
}

export default App;
